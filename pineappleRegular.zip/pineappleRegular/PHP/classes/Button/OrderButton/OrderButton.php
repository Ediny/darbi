<?php
namespace Button\OrderButton;

//selects input button and sets its value for ORDER BY

class OrderButton 
{
    public $button;

    public function __construct($button) 
    {
    $this->button = $button;
    }
    public function order() 
    {
    $sql = "SELECT * FROM email ORDER BY $this->button LIMIT 10";
    return $sql;
    }
}



