<?php
namespace Button\WhereButton;

//selects input button and sets its value for WHERE 

class WhereButton 
{
    public $button;

    public function __construct($button)
    {
    $this->button = $button;
    }
    public function where() 
    {
    $sql = "SELECT * FROM email WHERE input LIKE '%@$this->button%' LIMIT 10";
    return $sql;
    }
}


