<?php

//creates database connection

class Dbh 
{
    private $dbServername;
    private $dbUsername;
    private $dbPasspord;
    private $dbName;

    public function connect() 
    {
        $this->dbSevername = "localhost";
        $this->dbUsername = "root";
        $this->dbPasspord = "";
        $this->dbName = "test";

        $conn = new mysqli($this->dbServername, $this->dbUsername, $this->dbPasspord, $this->dbName);
        return $conn;
    }
}
