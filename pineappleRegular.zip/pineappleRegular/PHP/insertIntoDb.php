<?php

include_once './autoload.php';

$var = new Dbh();
$conn = $var->connect();
$email = mysqli_real_escape_string($conn, $_POST['email']);

//inserts data to mysql database//
$sql = "INSERT INTO email (input) VALUES ('$email');";
mysqli_query($conn, $sql);

//after 5 seconds after successful submission, takes user back to starting page
sleep(5);
header("Location: ../index.html");




