<?php

//creates a path for all files that are put in "classes" forlder for auto loading classes
spl_autoload_register('myAutoLoader');

function myAutoLoader($className) 
{
    $path = '../PHP/classes/';
    $className = str_replace(array('_', '\\'), '/', $className);
    $extension = '.php';
    include_once $fullPath = $path .  $className . $extension;

}