<?php
    include_once "./autoload.php";

// get id through query string
$id = $_GET['id']; 
$conn = new Dbh();
// delete query
$del = $conn->connect()->query("DELETE FROM email WHERE id = '$id'"); 

if ($del) {
    // Close connection
    $conn->connect()->close(); 
    // redirects to all records page
    header("location:../DataList/dataList.php"); 
    exit;	
} else {
    // display error message if not delete
    echo "Error deleting record"; 
}
