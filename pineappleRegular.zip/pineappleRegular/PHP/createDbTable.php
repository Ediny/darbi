<?php

//creates a table in database//

$table = "CREATE TABLE email (
    id int(10) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    date timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    input varchar(30) NOT NULL,
)";

