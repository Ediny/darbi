## Magebit test
This project is my second attempt of getting into your comapny. I tried to learn from my mistakes and the list of things i could improve upon from last attempts results really helped out.

## Description
In this project is split into 2 pages: in one of them(index) you can send valid data to database and in the other one(dataList) you can retrieve it and sort by date, name, domain and even search for specific text.

SCSS and SASS are implemented to easier maintain and write stylesheets, using variables, mixins, etc.

## Technologies
Project is created by using in addition:
*Vue.js 2.6.12,
*SASS

## Setup
Start your localserver and Mysql.

To get to homepage on local server, you need to go to: "localhost/new/index.html".

To get to page where database data can be seen, you need to go to: "localhost/new/DataList/dataList.php".

In dataList page I used inline style on elements because it is not visible to the user but can show my php skills 

Only part of PHP is made using OOP because I somehow couldn't make rest of them work using classes. 