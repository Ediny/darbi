<?php

use \Button\OrderButton\OrderButton as Order;
use \Button\WhereButton\WhereButton as Where;

    //sets $sql variable based on what the user selected so it can be used querying data
    
if (isset($_POST['date'])) {
    $var = new Order('date');
    $sql = $var->order();
} elseif (isset($_POST['input'])) {
    $var = new Order('input');
    $sql = $var->order();
} elseif (isset($_POST['search'])) {
    $valueToSeach = $_POST['searchValue'];
    $sql = "SELECT * FROM email WHERE input LIKE '%".$valueToSeach."%' LIMIT 10";
} elseif (isset($_POST['inbox'])) {
    $var = new Where('inbox');
    $sql = $var->where();
} elseif (isset($_POST['yahoo'])) {
    $var = new Where('yahoo');
    $sql = $var->where();
} elseif (isset($_POST['gmail'])) {
    $var = new Where('gmail');
    $sql = $var->where();
} else {
    $sql = "SELECT * FROM email";
}

