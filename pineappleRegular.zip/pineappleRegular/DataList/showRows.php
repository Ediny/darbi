<?php

//fetches and shows data from database based on what kind of imput the user selected

$conn = new Dbh();
if ($result = $conn->connect()->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        ?>
        <tr>
                <td><input type="checkbox" name="check_list[]" value="<?php echo $row['id'] ?>"/></td>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['date']; ?></td>
                <td><?php echo $row['input']; ?></td>
                <td><a href="../PHP/delete.php?id=<?php echo $row['id']; ?>">Delete</a></td> 
        </tr>
        <?php
    }
    $result->free();
}

?>