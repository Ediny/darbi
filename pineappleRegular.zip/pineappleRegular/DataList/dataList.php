<?php
    include_once "../PHP/autoload.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <title>List of Emails</title>
        <link rel="stylesheet" href="">
    </head>
    <body>

    <form align="center" method="POST">
        <!-- buttons for sorting date and name -->
        <input type="submit" name="date" value="Date">
        <input type="submit" name="input" value="Name"><br><br>
        <!-- input search -->
        <input type="text" name="searchValue" placeholder="Search"><br>
        <input type="submit" name="search" value="Filter"><br><br>
        <div>
            <!-- email sorting my domain -->
            <input value="inbox" type="submit" name="inbox">
            <input value="yahoo" type="submit" name="yahoo">
            <input value="gmail" type="submit" name="gmail">
        </div>
        <br>
            
    </form>
    <table id="table" align="center" border="1" cellspacing="3" cellpadding="3"> 
      <tr> 
          <td> <font face="Arial"></font> </td>
          <td> <font face="Arial">id</font> </td> 
          <td> <font face="Arial">date</font> </td> 
          <td> <font face="Arial">input</font> </td>
          <td> <font face="Arial">delete</font> </td>
      </tr>

      <!-- includes if statements -->
    <?php include './ifStatements.php';?>

    <!-- includes data query function -->
    <?php include './showRows.php';?>

    </table>

</body>
</html>