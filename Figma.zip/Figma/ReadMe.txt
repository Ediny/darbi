I have tons of figma projects working as freelance web designer but these are only
a few showing that I am comfortable with this program and have the knowledge of making 
websites as precise as needed.