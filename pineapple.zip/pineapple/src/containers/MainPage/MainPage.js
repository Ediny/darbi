import React, { Component } from 'react';

import '../../App.css';
import Content from '../../components/Content/Content';
import PineappleImage from '../../components/Pineapple/Pineapple';


class MainPage extends Component {


    render () {
    
        return (
            <div className="Main">
                <Content />
                <PineappleImage />
            </div>
        );
    }
}

export default MainPage;
