import React from 'react';

import '../../../App.css';
import Facebook from '../../../assets/SVG/facebookLogo';
import Instagram from '../../../assets/SVG/instagramLogo';
import Twitter from '../../../assets/SVG/twitterLogo';
import Youtube from '../../../assets/SVG/youtubeLogo';

const Social = () => {
    return (
        <div className="social">
            <a href="/"><Facebook /></a>
            <a href="/"><Instagram /></a>
            <a href="/"><Twitter /></a>
            <a href="/"><Youtube /></a>
        </div>
    );
}

export default Social;