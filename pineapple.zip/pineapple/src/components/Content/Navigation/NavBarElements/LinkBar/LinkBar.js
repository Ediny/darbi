import React from 'react';

import '../../../../../App.css';
import Links from '../Links/Links';

const LinkBar = () => {
    return (
    <ul className="LinkBar">
        <Links>About</Links>
        <Links>How it works</Links>
        <Links>Contact</Links>
    </ul>
    );
};

export default LinkBar;