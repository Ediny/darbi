import React from 'react';

import '../../../../../App.css';

const Links = (props) => (
    <li>
        <a href="/" className="Links">
            {props.children}
        </a>
    </li>
);

export default Links;

