import React from 'react';

import pineapple_Logo from '../../../../../assets/logo_pineapple.png';
import '../../../../../App.css';

const Logo = (props) => (
    <div className="Logo" style={{height: props.height}}>
        <img src={pineapple_Logo} alt="pineappe_Logo"/>
    </div>
);

export default Logo;