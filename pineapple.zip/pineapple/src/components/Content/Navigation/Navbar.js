import React from 'react';

import LinkBar from './NavBarElements/LinkBar/LinkBar';
import Logo from './NavBarElements/Logo/Logo';
import '../../../App.css';

const NavBar = (props) => {
    return (
        <div className="NavBar">
        <Logo height="80%" />
        <nav>
            <LinkBar />
        </nav>   
    </div>
    )
   
};

export default NavBar;