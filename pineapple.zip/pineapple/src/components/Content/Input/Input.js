import React, { Component } from 'react';
import axios from 'axios';

import '../../../App.css';
import Arrow from '../../../assets/SVG/Arrow';
import Trophy from '../../../assets/trophy.png';

class Input extends Component {
    constructor(props) {
    super(props);
    this.state = {
        input: {},
        errors: {},
        valid: false,
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
        let input = this.state.input;
        input[event.target.name] = event.target.value;

        this.setState({
            input
        });
    }

    handleSubmit(event) {
        event.preventDefault();
    
        if(this.validate()){
            let input = {};
            input["email"] = "";
            input["checkbox"] = null;
            this.setState({input:input});

            this.valid = true;


            axios.post('insertData.php', {
                input: this.state.input.email
            })
            .then((result) => {
                
                console.log(input);
            });
        }
    }

 
    
    validate(){
        let input = this.state.input;
        let errors = {};
        let isValid = true;

        if (!input["email"]) {
            isValid = false;
            errors["msg"] = "Please enter your email Address.";
        }

        if (typeof input["email"] !== "undefined") {
          
            const pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if (!pattern.test(input["email"])) {
              isValid = false;
              errors["msg"] = "Please enter valid email address.";
            }
          }

          if (typeof input["email"] !== "undefined") {
          
            const columbia = new RegExp(/[!@#$%^&*(),.?":{}|<>\\'.co'\\]/i);
            if (!columbia.test(input["email"])) {
              isValid = false;
              errors["msg"] = "NO .co!";
            }
          }
          
          if(!input["checkbox"]) {
              isValid = false;
              errors["msg"] = "You have to agree!";
          }

          this.setState({
              errors: errors
          });

          return isValid;

    }

    textDisplay = () => {;
        if(this.valid) {
            return (
            <div className="Text">
                <img className="trophy" src={Trophy} alt="trophy" />
                <h3>Thanks for subscribing!</h3>
                <p>You have successfully subscribed to our email listing. Check your email for discount code.</p>
            </div>
            );
        } else {
            return (
                <div className="Text">
                <h3>Subscribe to newsletter</h3>
                <p>Subscribe to our newsletter and get 10% discount on pineapple glasses.</p>
            </div>
            );
        };
    }

    render() {
        return (

        <div>
        <this.textDisplay />
        <form action="" method="POST" style={{display: this.valid ? "none" : "block"}} onSubmit={this.handleSubmit}>
            <div className="InputBox">
                <input
                id="email"
                type="email" 
                value={this.state.input.email}
                onChange={this.handleChange} 
                name="email"
                className="Email" 
                placeholder="Type your email here..."
                 />
                <button 
                className="Button" 
                value="Submit" 
                name="submit" 
                type="submit">
                <Arrow />
                </button>
            </div>
            <div className="checkbox">
                <input
                type="checkbox" 
                id="checkbox" 
                name="checkbox"
                onChange={this.handleChange} />
                <label  htmlFor="checkbox"> 
                    I agree to <a href="/" className="services">terms and services</a>
                </label>
            </div> 
            <div className="errorMsg">{this.state.errors.msg}</div> 
        </form>
        </div>
        
        );
    }
}

  


export default Input;