import React, { Component } from 'react';

import '../../App.css';
import Navigation from './Navigation/Navbar';

import Input from './Input/Input';
import Social from './Social/Social';



class Content extends Component {
    
    render () {

        return (
            <div className="LeftSide">
                <Navigation />
                <Input />
                <hr />
                <Social />
                
            </div>
        );
    }
}

export default Content;