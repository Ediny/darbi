import React from 'react';

import Pineapple from '../../assets/Chill.png';
import '../../App.css';

const PineappleImage = () => (
    <div className="RightSide">
        <img src={Pineapple} alt="Pineapple" />
    </div>
);

export default PineappleImage;